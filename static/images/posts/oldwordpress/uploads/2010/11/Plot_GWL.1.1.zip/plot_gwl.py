'''
Printing GWL File in 3D
Version 1.1
Date : 22/11/2010

Written by Jean-Christophe Lavocat - http://jice.lavocat.name
'''

from init_physics import *
from mpl_toolkits.mplot3d import Axes3D
import string
import re

#Define a basic string2float function
def str2num(s):
    return ("." in s and [float(s)] or [int(s)])[0]


# Define the writing area

Xoffset = 50.0
Yoffset = 50.0
Zoffset = 20.0
coord_arr = ([])

coordfile = open('your_filename.gwl','r')
while 1:
        txt = coordfile.readline() #open the file
        if txt =="": #if empty, exit
        	break
	elif (txt[0] != "%" and txt[0:4] != '-999' and txt[0] and not re.search('[a-zA-Z]',txt)): #if the line is not a comment, an instruction or contain text
		list = string.split(txt) #Make a list out of the line
        	coord_arr.append( map(str2num,list)[0:3]) #Add them to the array of point
coordfile.close()
print str(len(coord_arr))+" points to plot."


fig = plt.figure()
ax = Axes3D(fig)
for i in coord_arr:
	if (i[0]+Xoffset > 300 or i[1]+Yoffset > 300 or i[2]+Zoffset > 80):
		ax.scatter([i[0]+Xoffset], [i[1]+Yoffset], [i[2]+Zoffset], c='r', marker='o') # The working window is 300um wide, not more. Plot in red if out of the window
	else:
		ax.scatter([i[0]+Xoffset], [i[1]+Yoffset], [i[2]+Zoffset], c='b', marker='o') # Else, plot in blue

ax.set_xlabel('X Label')
ax.set_ylabel('Y Label')
ax.set_zlabel('Z Label')

plt.show()


