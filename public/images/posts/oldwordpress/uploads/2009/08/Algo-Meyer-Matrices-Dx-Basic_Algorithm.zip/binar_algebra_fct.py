"""
Contains all the functions relative to the binary algebra
"""

def bin2int(n):
	"""
	Return the integer value of the binary value of n
	It's easier to give n as a str n='100101011'
	"""
	
	return(int(str(n),2))

	
def int2bin(n, count=1):
	"""
	Returns the binary of integer n, using count number of digits
	int2bin(n,count) allows you to fix the number of bits : count
	"""
	
	n=int(n)
	def Denary2Binary(n):
		'convert denary integer n to binary string bStr'
		
		bStr = ''
		if n < 0: raise ValueError, "must be a positive integer"
		if n == 0: return '0'
		while n > 0:
			bStr = str(n % 2) + bStr
			n = n >> 1
		return bStr
		
	count=max(len(Denary2Binary(n)),count)
	return "".join([str((n >> y) & 1) for y in range(count-1, -1, -1)])

def hamming_distance(s1, s2):
	""" Returns the hamming distance between bitstrings s1 and s2 """
	
	assert len(s1) == len(s2)
	return sum([ch1 != ch2 for ch1, ch2 in zip(s1, s2)])
