# this file <init_physics.py> is to be executed at the beginning of each Python session
# With the following command : 'from init_physics import *'
# This module should stay in this folder, or the new folder should be add to /usr/local/lib/python2.6/dist-packages

print '--------------------------------------------------------'
print 'Initialization with ~/PhD/Python/Modules/init_physics.py'
from scipy import *
print 'Scipy loaded'
import physcon as pc
print 'Physical constants in module pc. Type pc.help()'
import matplotlib.pyplot as plt
print 'Matplotlib loaded. Use it with prefix plt. (ex : plt.plot([1, 2, 3]))'


print 'Initialization Completed'
print '--------------------------------------------------------'
