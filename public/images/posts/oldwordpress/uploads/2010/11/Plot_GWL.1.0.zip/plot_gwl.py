'''
Test affichage fonction et sous-figures
'''

from init_physics import *
import string
import re

#Define a basic string2float function
def str2num(s):
    return ("." in s and [float(s)] or [int(s)])[0]


# Define the writing area

Xoffset = 10.0
Yoffset = 10.0
coord_arr = ([])

coordfile = open('your_file.gwl','r')
while 1:
        txt = coordfile.readline()
        if txt =="":
        	break
	elif (txt[0] != "%" and txt[0:4] != '-999' and txt[0] and not re.search("i",txt)):
		list = string.split(txt)
        	coord_arr.append( map(str2num,list)[0:2])
coordfile.close()
print str(len(coord_arr))+" points to plot."

for i in coord_arr:
	if (i[0]+Xoffset > 300 or i[1]+Yoffset > 300):
		plt.plot(i[0]+Xoffset,i[1]+Yoffset,'r.') # The working window is 300um wide, not more. Plot in red if out of the window
	else:
		plt.plot(i[0]+Xoffset,i[1]+Yoffset,'b.') # Else, plot in blue

plt.axis([0, 400, 0, 200])
plt.show()

