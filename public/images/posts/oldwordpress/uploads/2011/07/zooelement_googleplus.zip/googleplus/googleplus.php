<?php
/**
* @package   ZOO Component
* @file      facebookilike.php
* @version   2.4.9 May 2011
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) 2007 - 2011 YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
*/

/*
   Class: ElementGooglePlus
       The Google +1 element class
*/
class ElementGooglePlus extends Element implements iSubmittable {


/*
		Function: hasValue
			Checks if the element's value is set.

	   Parameters:
			$params - render parameter

		Returns:
			Boolean - true, on success
	*/
public function hasValue($params = array()) {
		return true;
	}
	
	/*
		Function: render
			Override. Renders the element.

	   Parameters:
            $params - render parameter

		Returns:
			String - html
	*/
	public function render($params = array()) {

		// init vars
		$params		= $this->app->data->create($params);
		$size		= $params->get('size');
		$show_counts = $params->get('show_counts') ;
		$lang 		= $params->get('lang') ? '&amp;lang='.$params->get('lang') : '';
		
		// render html
		$document =& JFactory::getDocument();
		$document->addScript("https://apis.google.com/js/plusone.js");
		//$document->addScriptDeclaration("{lang: 'fr'}");
		

			$permalink = (JRoute::_($this->app->route->item($this->_item), true, -1));

			$button = "<g:plusone size='".$size."' href='".$permalink."' count='".$show_counts."'></g:plusone>";
			//$html = '<iframe src="'.$href.'" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width: '.$width.'px; height: '.$height.'px;" ></iframe>';
			
			return $button;
		

	}

	/*
	   Function: edit
	       Renders the edit form field.

	   Returns:
	       String - html
	*/
	public function edit() {
		// init vars
		$default = $this->_config->get('default');

		if ($default != '' && $this->_item != null && $this->_item->id == 0) {
			$this->_data->set('value', 1);
		}

		return $this->app->html->_('select.booleanlist', 'elements[' . $this->identifier . '][value]', '', $this->_data->get('value'));
	}

	/*
		Function: renderSubmission
			Renders the element in submission.

	   Parameters:
            $params - submission parameters

		Returns:
			String - html
	*/
	public function renderSubmission($params = array()) {
        return $this->edit();
	}

	/*
		Function: validateSubmission
			Validates the submitted element

	   Parameters:
            $value  - AppData value
            $params - AppData submission parameters

		Returns:
			Array - cleaned value
	*/
	public function validateSubmission($value, $params) {
		return array('value' => $value->get('value'));
	}

}